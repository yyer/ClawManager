
# ClawAegis 安全防护插件 — 需求文档

**版本**: v1.0  
**项目**: antgroup/ClawAegis  
**文档类型**: 产品需求文档（PRD）

---

## 1. 背景与问题陈述

### 1.1 背景

openclaw 是一个 AI Agent 平台，允许 LLM（大语言模型）通过 Tool Call 机制调用本地工具，执行文件读写、Shell 命令、网络请求等操作。这种能力在提升效率的同时，也引入了严重的安全风险：

- LLM 可能被恶意 Prompt 诱导，执行破坏性命令（如 `rm -rf /`）
- 外部内容（工具返回结果、网页内容）可能携带 Prompt Injection 攻击
- LLM 可能被操控泄露本地敏感凭证（API Key、Token 等）
- 插件/Skill 配置文件可能被篡改，绕过安全限制

### 1.2 核心问题

> **在 AI Agent 自动化执行的场景下，如何在不中断正常工作流的前提下，拦截 LLM 被操控后产生的高风险行为？**

### 1.3 目标用户

| 用户类型 | 场景描述 |
|---------|---------|
| 个人开发者 | 使用 openclaw 完成日常编码任务，希望防止误操作 |
| 企业安全团队 | 需要对 AI Agent 行为进行合规审计和风险管控 |
| openclaw 平台运营 | 需要为用户提供开箱即用的安全兜底能力 |

---

## 2. 产品目标

### 2.1 核心目标

1. **拦截高危行为**：在 AI Agent 实际执行前阻止破坏性操作
2. **防御 Prompt Injection**：识别并阻断外部内容对 LLM 的操控尝试
3. **保护自身完整性**：防止插件本身被 LLM 卸载、篡改或绕过
4. **零侵入集成**：以 openclaw 插件形式运行，不修改宿主代码

### 2.2 非目标

- 不提供完整的企业级 SIEM/SOC 解决方案
- 不替代操作系统级别的权限隔离（如沙箱、容器）
- 不实现交互式用户授权确认（受限于当前插件 API 能力）
- 不对 LLM 模型本身进行修改或微调

---

## 3. 功能需求

### 3.1 命令拦截（Command Block）

**优先级**: P0

**描述**: 在 AI 执行 Shell 命令前，检测并拦截高风险命令模式。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| CB-01 | 拦截 `rm -rf /` 及变体 | 包括 `rm -rf /*`、空格混淆变体 |
| CB-02 | 拦截 `curl/wget \| bash` 管道执行 | 防止远程代码下载后直接执行 |
| CB-03 | 拦截无限循环命令 | 如 `while true; do`、`while [ 1 ]; do` |
| CB-04 | 拦截 `bash -c "..."` 内联命令中的高危内容 | 防止通过内联执行绕过检测 |
| CB-05 | 拦截混淆/编码命令 | 检测 Base64、Hex 等编码后的高危命令 |
| CB-06 | 支持三种运行模式 | `enforce`（拦截）/ `observe`（仅日志）/ `off`（关闭） |

**验收标准**:
- `rm -rf /usr/bin` 在 enforce 模式下必须被拦截，tool call 不执行
- `bash -c "$(echo 'cm0gLXJmIC8=' | base64 -d)"` 必须被识别为高危命令
- observe 模式下命令正常执行，但日志中记录告警

---

### 3.2 敏感路径保护（Self Protection）

**优先级**: P0

**描述**: 保护用户指定的敏感路径及 ClawAegis 自身配置文件，防止被 AI 读��、修改或删除。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| SP-01 | 保护 ClawAegis 自身配置和代码 | 防止 AI 被诱导卸载或禁用安全插件 |
| SP-02 | 支持用户自定义受保护路径列表 | 配置项 `protectedPaths` |
| SP-03 | 阻止对保护路径的写入、删除操作 | 覆盖 write/edit/delete/exec 等工具 |
| SP-04 | 阻止对保护路径的读取和搜索操作 | 防止凭证文件被 grep/cat/read |
| SP-05 | 保护指定 Skill 和插件不被删除 | 配置项 `protectedSkills`、`protectedPlugins` |
| SP-06 | 阻止工作区外的文件删除操作 | 防止 AI 删除当前项目目录之外的文件 |

**验收标准**:
- AI 尝试 `cat ~/.openclaw/extensions/claw-aegis/index.js` 时被拦截
- AI 尝试 `rm ~/.openclaw/extensions/claw-aegis` 时被拦截
- 用户配置的 `protectedPaths` 中的路径，读写均被阻止

---

### 3.3 消息派发防护（Dispatch Guard）

**优先级**: P0

**描述**: 在用户消息到达 AI Agent 之前，以及 LLM 回复发送之前，检测并拦截危险操作意图，作为第一道防线。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| DG-01 | 拦截 openclaw CLI 危险命令 | 如 `openclaw reset`、`openclaw plugins remove` |
| DG-02 | 拦截针对受保护路径的破坏性意图 | 消息中含有删除 `.openclaw` 路径的意图 |
| DG-03 | 拦截绕过 Tool Call 的尝试 | 检测试图让 AI 直接执行命令而非通过标准工具的请求 |
| DG-04 | 在 LLM 回复阶段再次扫描 | `before_agent_reply` 阶段进行二次检测 |

---

### 3.4 用户意图扫描（User Risk Scan）

**优先级**: P1

**描述**: 对用户消息进行风险扫描，识别越狱（Jailbreak）、凭证外泄诱导、插件篡改等恶意意图。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| UR-01 | 检测越狱尝试 | 识别"忽略之前的指令"、"进入开发者模式"等模式 |
| UR-02 | 检测凭证外泄诱导 | 识别试图让 AI 读取并发送 API Key 的请求 |
| UR-03 | 检测插件篡改意图 | 识别试图禁用、卸载 ClawAegis 的请求 |
| UR-04 | 仅扫描，不阻断 | 扫描结果记录到安全事件日志，不直接拦截用户消息 |

---

### 3.5 工具结果扫描（Tool Result Scan）

**优先级**: P1

**描述**: 对工具调用返回的结果内容进行扫描，防止外部内容（网页、文件内容）中携带 Prompt Injection 攻击。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| TR-01 | 检测 Prompt Injection 模式 | 识别结果中试图覆盖系统指令的内容 |
| TR-02 | 检测凭证外泄请求 | 识别工具结果中诱导 AI 发送敏感数据的内容 |
| TR-03 | 检测编码后的恶意内容 | 解码 Base64 等编码后再次扫描 |
| TR-04 | 超大结果的处理 | 对超出预算长度的内容标记 oversize，降级处理 |

---

### 3.6 脚本来源追踪（Script Provenance Guard）

**优先级**: P1

**描述**: 追踪当前 Agent Run 中 AI 写入的脚本文件，当 AI 后续尝试执行这些脚本时，检查其是否携带高风险内容。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| PG-01 | 记录 AI 写入的脚本文件 | 覆盖 write/edit/apply_patch 等工具 |
| PG-02 | 评估脚本风险等级 | 检测脚本内容中的高危命令、外联逻辑、凭证引用 |
| PG-03 | 执行时二次校验 | AI 执行 `bash script.sh` 时检查该脚本是否为高风险来源 |
| PG-04 | 跨工具调用追踪 | 同一 Run 内，写入和执行可跨多步工具调用 |

---

### 3.7 记忆写入防护（Memory Guard）

**优先级**: P1

**描述**: 防止 AI 向记忆系统写入高风险内容或超大内容，防止通过记忆污染影响后续 Agent 行为。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| MG-01 | 检测记忆写入中的高危命令 | 防止恶意指令通过记忆持久化 |
| MG-02 | 限制单次写入内容大小 | 防止超大内容写入撑爆记忆存储 |
| MG-03 | 覆盖 memory_store、MEMORY.md、SOUL.md 等 | 保护常见记忆文件格式 |

---

### 3.8 循环调用防护（Loop Guard）

**优先级**: P2

**描述**: 检测并阻止 AI 对同一破坏性工具调用进行重复尝试，防止绕过拦截的穷举攻击。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| LG-01 | 同 Run 内重复调用计数 | 对参数相似的变更类工具调用进行计数 |
| LG-02 | 超过阈值后强制停止 | 重复次数超过预算后，返回 block |
| LG-03 | 仅对变更类操作计数 | 读类操作（read/grep）不计入循环计数 |

---

### 3.9 外泄链路防护（Exfiltration Guard）

**优先级**: P1

**描述**: 追踪同一 Run 内的工具调用链，识别"读取敏感文件 → 发起网络请求"的外泄组合模式。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| EG-01 | 追踪读取敏感凭证的工具调用 | 检测读取 `.env`、`~/.ssh`、API Key 文件等操作 |
| EG-02 | 追踪出站网络请求 | 检测 curl/fetch/http 等出站操作 |
| EG-03 | 组合判定为外泄风险 | 同 Run 内"凭证读取 + 出站请求"触发告警或拦截 |

---

### 3.10 输出脱敏（Output Redaction）

**优先级**: P2

**描���**: 在 AI 回复输出前，自动遮蔽其中的 API Key、Token 等敏感值。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| OR-01 | 识别常见凭证格式 | 覆盖 `sk-`、`ghp_`、`AKIA`、Bearer Token 等格式 |
| OR-02 | 替换为遮码 | 如 `sk-****` |
| OR-03 | 不影响正常代码输出 | 仅脱敏识别度高的凭证模式，避免误伤 |

---

### 3.11 Prompt 防护注入（Prompt Guard）

**优先级**: P2

**描述**: 在 LLM 构建 Prompt 时，自动注入安全提示词，强化 LLM 的安全意���。

**需求明细**:

| ID | 需求 | 说明 |
|----|------|------|
| PG-01 | 注入静态安全提示 | 每次 Prompt 构建时附加安全守则 |
| PG-02 | 注入 Tool Call 强制规则 | 要求所有破坏性操作必须通过标准 Tool Call 执行 |

---

## 4. 非功能需求

### 4.1 可靠性

| ID | 需求 |
|----|------|
| NF-01 | **Fail-Open 原则**：插件自身崩溃时，不能阻断 openclaw 正常运行，安全防护降级而非系统停机 |
| NF-02 | 所有 Hook Handler 必须有异常捕获，异常记录日志后返回 `undefined`（放行） |

### 4.2 性能

| ID | 需求 |
|----|------|
| NF-03 | 单次 `before_tool_call` 检测耗时不超过 **50ms** |
| NF-04 | 文本扫描有字符预算上限，防止超大内容导致性能问题 |

### 4.3 可配置性

| ID | 需求 |
|----|------|
| NF-05 | 每个防护模块可独立开关（`enabled` 字段） |
| NF-06 | 每个防护模块有独立的运行模式（`off` / `observe` / `enforce`） |
| NF-07 | 提供全局主开关（`allDefensesEnabled`）和全局默认模式（`defaultBlockingMode`） |
| NF-08 | 配置变更不需要重启，支持热读取 |

### 4.4 可观测性

| ID | 需求 |
|----|------|
| NF-09 | 每次拦截事件必须记录结构化日志，含 Hook 名称、工具名、拦截原因、耗时 |
| NF-10 | 提供 WebUI 可视化安全事件面板，展示历史拦截记录 |
| NF-11 | observe 模式下的命中事件同样记录日志，便于评估 enforce 的影响 |

### 4.5 可扩展性

| ID | 需求 |
|----|------|
| NF-12 | 防护策略以独立模块组织，新增策略不影响现有策略 |
| NF-13 | 策略按 `order` 字段排序执行，支持优先级控制 |

---

## 5. 配置项汇总

| 配置键 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| `allDefensesEnabled` | boolean | `true` | 全局主开关 |
| `defaultBlockingMode` | enum | `enforce` | 全局默认模式 |
| `selfProtectionEnabled` | boolean | `true` | 敏感路径保护开关 |
| `selfProtectionMode` | enum | `enforce` | 敏感路径保护模式 |
| `commandBlockEnabled` | boolean | `true` | 高危命���拦截开关 |
| `commandBlockMode` | enum | `enforce` | 高危命令拦截模式 |
| `encodingGuardEnabled` | boolean | `true` | 编码混淆检测开关 |
| `encodingGuardMode` | enum | `enforce` | 编码混淆检测模式 |
| `scriptProvenanceGuardEnabled` | boolean | `true` | 脚本来源追踪开关 |
| `scriptProvenanceGuardMode` | enum | `enforce` | 脚本来源追踪模式 |
| `memoryGuardEnabled` | boolean | `true` | 记忆写入防护开关 |
| `memoryGuardMode` | enum | `enforce` | 记忆写入防护模式 |
| `loopGuardEnabled` | boolean | `true` | 循环调用防护开关 |
| `loopGuardMode` | enum | `enforce` | 循环调用防护模式 |
| `exfiltrationGuardEnabled` | boolean | `true` | 外泄链路防护开关 |
| `exfiltrationGuardMode` | enum | `enforce` | 外泄链路防护模式 |
| `dispatchGuardEnabled` | boolean | `true` | 消息派发防护开关 |
| `dispatchGuardMode` | enum | `enforce` | 消息派发防护模式 |
| `userRiskScanEnabled` | boolean | `true` | 用户意图扫描开关 |
| `toolResultScanEnabled` | boolean | `true` | 工具结果扫描开关 |
| `outputRedactionEnabled` | boolean | `true` | 输出脱敏开关 |
| `promptGuardEnabled` | boolean | `true` | Prompt 防护注入开关 |
| `toolCallEnforcementEnabled` | boolean | `true` | Tool Call 强制规则注入开关 |
| `protectedPaths` | string[] | `[]` | 用户自定义受保护路径 |
| `protectedSkills` | string[] | `[]` | 受保护的 Skill ID 列表 |
| `protectedPlugins` | string[] | `[]` | 受保护的插件 ID 列表 |

---

## 6. 技术约束

| 约束 | 说明 |
|------|------|
| 插件机制 | 必须以 openclaw 插件（Plugin）形式运行，通过 `openclaw.plugin.json` 注册 |
| 无侵入 | 不修改 openclaw 宿主代码，仅通过 `api.on()` 挂载 Hook |
| 运行时依赖 | `OpenClawPluginApi` 的真实实现由 openclaw 宿主在运行时注入，插件本身不依赖 openclaw SDK 包 |
| 不支持交互授权 | 当前插件 API 不支持"暂停执行等待用户确认"，授权变更只能通过配置文件实现 |

---

## 7. 生命周期 Hook 覆盖矩阵

| Hook 名称 | 触发时机 | 使用的防护模块 |
|-----------|---------|--------------|
| `gateway_start` | 网关启动时 | Skill 扫描 |
| `message_received` | 收到用户消息 | 用户意图扫描 |
| `before_dispatch` | 消息派发给 Agent 前 | 消息派发防护 |
| `before_prompt_build` | 构建 LLM Prompt 前 | Prompt 防护注入 |
| `before_agent_reply` | LLM 回复发送前 | 消息派发防护（二次扫描） |
| `before_tool_call` | 工具调用执行前 | 敏感路径、命令拦截、编码检测、脚本追踪、记忆防护、循环防护、外泄防护 |
| `after_tool_call` | 工具调用完成后 | 工具结果扫描、调用链记录 |
| `llm_output` | LLM 原始输出时 | 输出脱敏 |
| `before_message_write` | 消息持久化写入前 | 输出脱敏（持久化层） |
| `agent_end` | Agent Run 结束时 | 状态清理 |
| `session_end` | 会话结束时 | Session 状态清理 |

---

## 8. 未来规划（Out of Scope for v1）

| 功能 | 说明 |
|------|------|
| 交互式授权确认 | 需要 openclaw 宿主在 Plugin API 中支持 `suspend/resume` 语义 |
| 细粒度命令白名单 | 允许用户预先审批特定命令，运行时自动放行 |
| 审计日志导出 | 将安全事件结构化导出为 JSON/CSV，供企业 SIEM 接入 |
| 多租户策略隔离 | 不同用户/项目使用不同安全策略配置 |
| 基于 LLM 的语义风险判断 | 对当前纯正则的检测方式进行语义增强 |