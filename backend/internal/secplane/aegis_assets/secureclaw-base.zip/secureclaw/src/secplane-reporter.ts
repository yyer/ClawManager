// SecureClaw → ClawManager secplane ingest shipper.
//
// Mirrors the ClawAegis pattern (see ClawAegis/src/handlers.ts
// postEventToSecplane). Reads CLAWMANAGER_AGENT_BASE_URL +
// CLAWMANAGER_INSTANCE_TOKEN injected by the openclaw-agent. All HTTP is
// fire-and-forget with a 30s abort so a slow/unreachable backend never
// blocks the SecureClaw plugin's main flow. JSONL on disk remains the
// source of truth.

import type { AuditFinding, MonitorAlert, Severity } from './types.js';

const SECPLANE_INGEST_PATH = '/api/v1/secplane/agent/sec_events/batch';
const SHIPPER_TIMEOUT_MS = 30_000;

/** Minimum severity that triggers a secplane post. */
const SEVERITY_RANK: Record<Severity, number> = {
  INFO: 0,
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3,
  CRITICAL: 4,
};

const MIN_REPORT_RANK = SEVERITY_RANK.MEDIUM;

/** Shape posted to ClawManager. Matches IngestEvent in
 *  backend/internal/secplane/ingest/handler.go. */
interface IngestEvent {
  event_id: string;
  ts: string;
  hook: string;
  defense: string;
  rule_id: string;
  rule_name: string;
  severity: 'low' | 'medium' | 'high';
  result: 'observed' | 'blocked' | 'allowed';
  reason: string;
  subject: string;
  evidence: string;
  raw_payload: string;
}

function severityToWire(s: Severity): 'low' | 'medium' | 'high' {
  switch (s) {
    case 'CRITICAL':
    case 'HIGH':
      return 'high';
    case 'MEDIUM':
      return 'medium';
    default:
      return 'low';
  }
}

function shouldReport(s: Severity): boolean {
  return SEVERITY_RANK[s] >= MIN_REPORT_RANK;
}

function newEventID(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function postEvents(events: IngestEvent[]): void {
  const baseURL = process.env.CLAWMANAGER_AGENT_BASE_URL;
  const token =
    process.env.CLAWMANAGER_INSTANCE_TOKEN || process.env.CLAWMANAGER_LLM_API_KEY;
  if (!baseURL || !token || events.length === 0) return;

  const url = baseURL.replace(/\/$/, '') + SECPLANE_INGEST_PATH;
  const body = JSON.stringify({ source: 'secureclaw', events });

  const f = (globalThis as unknown as { fetch?: typeof fetch }).fetch;
  if (!f) return;

  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), SHIPPER_TIMEOUT_MS);
  f(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${token}`,
    },
    body,
    signal: ac.signal,
  })
    .catch(() => {
      /* fail-open — disk JSONL is authoritative */
    })
    .finally(() => clearTimeout(timer));
}

/** Report an AuditFinding (only if severity >= MEDIUM). Multiple findings
 *  can be batched via reportAuditFindings to amortize the HTTP round-trip. */
export function reportAuditFindings(findings: readonly AuditFinding[]): void {
  const events = findings
    .filter((f) => shouldReport(f.severity))
    .map<IngestEvent>((f) => ({
      event_id: newEventID('secureclaw-audit'),
      ts: new Date().toISOString(),
      hook: 'audit',
      defense: 'audit',
      rule_id: `secureclaw.audit.${f.id}`,
      rule_name: f.title,
      severity: severityToWire(f.severity),
      result: 'observed',
      reason: f.description,
      subject: `secureclaw.audit.${f.category}`,
      evidence: f.evidence,
      raw_payload: JSON.stringify({
        id: f.id,
        owaspAsi: f.owaspAsi,
        maestroLayer: f.maestroLayer,
        nistCategory: f.nistCategory,
        remediation: f.remediation,
        autoFixable: f.autoFixable,
      }).slice(0, 2048),
    }));
  postEvents(events);
}

/** Report a single monitor alert. Background monitors call this from their
 *  onAlert subscriber registered in onGatewayStart. */
export function reportMonitorAlert(monitorName: string, alert: MonitorAlert): void {
  if (!shouldReport(alert.severity)) return;
  const ev: IngestEvent = {
    event_id: newEventID(`secureclaw-${monitorName}`),
    ts: alert.timestamp,
    hook: 'monitor',
    defense: monitorName,
    rule_id: `secureclaw.${monitorName}.alert`,
    rule_name: `${monitorName}-monitor`,
    severity: severityToWire(alert.severity),
    result: 'observed',
    reason: alert.message,
    subject: `secureclaw.${monitorName}`,
    evidence: alert.details ?? alert.message,
    raw_payload: JSON.stringify(alert).slice(0, 2048),
  };
  postEvents([ev]);
}

/** Report kill switch activation / deactivation. */
export function reportKillSwitch(state: 'activated' | 'deactivated', reason?: string): void {
  const ev: IngestEvent = {
    event_id: newEventID('secureclaw-killswitch'),
    ts: new Date().toISOString(),
    hook: 'lifecycle',
    defense: 'killSwitch',
    rule_id: 'secureclaw.killswitch.' + (state === 'activated' ? 'activate' : 'deactivate'),
    rule_name: 'killSwitch',
    severity: state === 'activated' ? 'high' : 'low',
    result: state === 'activated' ? 'blocked' : 'allowed',
    reason: reason ?? '',
    subject: 'secureclaw.killSwitch',
    evidence: reason ?? '',
    raw_payload: JSON.stringify({ state, reason }).slice(0, 2048),
  };
  postEvents([ev]);
}
