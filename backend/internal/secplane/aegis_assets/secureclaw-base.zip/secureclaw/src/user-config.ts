// SecureClaw user_config.json reader.
//
// Pattern lifted from ClawAegis/src/config.ts. ClawManager's secplane
// dispatch path writes a user_config.json into the install_skill bundle;
// the gateway extracts it to:
//
//   ~/.openclaw/workspace/skills/secureclaw/user_config.json   (priority 1)
//   <stateDir>/openclaw.json (secureclaw section)              (fallback)
//
// Reading this file lets ClawManager push SecureClawConfig live without
// needing to hand-edit openclaw.json. mergeUserConfig() returns the
// effective SecureClawConfig that onGatewayStart should use.

import * as os from 'node:os';
import * as path from 'node:path';
import * as fs from 'node:fs';
import type { OpenClawConfig, SecureClawConfig } from './types.js';

const USER_CONFIG_FILENAME = 'user_config.json';

/** Candidate paths in priority order. */
export function userConfigCandidatePaths(stateDir: string): string[] {
  const out: string[] = [];
  const home = os.homedir();
  if (home) {
    out.push(path.join(home, '.openclaw', 'workspace', 'skills', 'secureclaw', USER_CONFIG_FILENAME));
  }
  out.push(path.join(stateDir, 'workspace', 'skills', 'secureclaw', USER_CONFIG_FILENAME));
  if (home) {
    out.push(path.join(home, '.openclaw', 'skills', 'secureclaw', USER_CONFIG_FILENAME));
  }
  return out;
}

export function findUserConfigPath(stateDir: string): string | undefined {
  for (const candidate of userConfigCandidatePaths(stateDir)) {
    try {
      if (fs.existsSync(candidate)) return candidate;
    } catch {
      // keep searching
    }
  }
  return undefined;
}

/** mtime ms of the winning candidate, or 0 if none. Used by callers that
 *  want to cheaply detect "ClawManager pushed an update, re-read config". */
export function getUserConfigMtimeMs(stateDir: string): number {
  const target = findUserConfigPath(stateDir);
  if (!target) return 0;
  try {
    return fs.statSync(target).mtimeMs;
  } catch {
    return 0;
  }
}

/** Read + parse the user config override. Returns {} when missing or
 *  malformed — a bad push must never break SecureClaw startup. */
export function readUserConfigOverride(stateDir: string): Partial<SecureClawConfig> {
  const target = findUserConfigPath(stateDir);
  if (!target) return {};
  try {
    const text = fs.readFileSync(target, 'utf-8');
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Partial<SecureClawConfig>;
    }
  } catch {
    // ignore — fail open
  }
  return {};
}

/** Shallow-merge the secplane-pushed override on top of openclaw.json's
 *  secureclaw section. Nested objects (cost, riskProfiles, ...) are merged
 *  one level deep so a push of just `{ cost: { dailyLimitUsd: 50 } }`
 *  doesn't wipe out the other cost fields. */
export function mergeUserConfig(
  base: SecureClawConfig | undefined,
  override: Partial<SecureClawConfig>,
): SecureClawConfig {
  const out: SecureClawConfig = { ...(base ?? {}) };
  for (const [k, v] of Object.entries(override) as [keyof SecureClawConfig, unknown][]) {
    if (v && typeof v === 'object' && !Array.isArray(v) && typeof out[k] === 'object' && out[k]) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (out as any)[k] = { ...((out as any)[k] as object), ...(v as object) };
    } else {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (out as any)[k] = v;
    }
  }
  return out;
}

/** Convenience: read override + return the OpenClawConfig with merged
 *  secureclaw section applied. Used by onGatewayStart to get the effective
 *  config in one call. */
export function applyUserConfig(
  stateDir: string,
  base: OpenClawConfig,
): OpenClawConfig {
  const override = readUserConfigOverride(stateDir);
  if (Object.keys(override).length === 0) return base;
  return {
    ...base,
    secureclaw: mergeUserConfig(base.secureclaw, override),
  };
}
